function out = smoothMap(map,factor)
if nargin<2
    factor = 10;
end
ydim = size(map,1)*factor;
xdim = size(map,2)*factor;
    out = zeros(ydim,xdim);
    for i = 1:ydim
        for j = 1:xdim
            coord = ceil([i/factor,j/factor]);
            out(i,j) = map(coord(1),coord(2));
        end
    end
    out = imgaussfilt(out,factor);
end
